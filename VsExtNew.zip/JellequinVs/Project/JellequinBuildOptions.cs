﻿namespace Tvl.VisualStudio.Language.Jellequin.Project
{
    using Tvl.VisualStudio.Language.Jellequin.Project.PropertyPages;

    public sealed class JellequinBuildOptions
    {
        //private JellequinGeneralPropertyPagePanel _general;
        //private JellequinBuildPropertyPagePanel _build;
        //private JellequinDebugPropertyPagePanel _debug;

        /*public JellequinGeneralPropertyPagePanel General
        {
            get
            {
                return _general;
            }

            set
            {
                _general = value;
                if (_general != null)
                    _general.Disposed += (sender, e) => _general = null;
            }
        }

        public JellequinBuildPropertyPagePanel Build
        {
            get
            {
                return _build;
            }

            set
            {
                _build = value;
                if (_build != null)
                    _build.Disposed += (sender, e) => _build = null;
            }
        }

        public JellequinDebugPropertyPagePanel Debug
        {
            get
            {
                return _debug;
            }

            set
            {
                _debug = value;
                if (_debug != null)
                    _debug.Disposed += (sender, e) => _debug = null;
            }
        }*/
    }
}
