﻿namespace Tvl.VisualStudio.Language.Jellequin.Project
{
    public enum FolderBuildAction
    {
        Folder,
        SourceFolder,
        TestSourceFolder,
    }
}
