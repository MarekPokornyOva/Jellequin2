﻿using System.Linq;
using Microsoft.VisualStudio;
using Tvl.VisualStudio.Language.Jellequin.Project;
using Tvl.VisualStudio.Shell;

using __VSDBGLAUNCHFLAGS = Microsoft.VisualStudio.Shell.Interop.__VSDBGLAUNCHFLAGS;
//using __VSDBGLAUNCHFLAGS2 = Microsoft.VisualStudio.Shell.Interop.__VSDBGLAUNCHFLAGS2;
using DEBUG_LAUNCH_OPERATION = Microsoft.VisualStudio.Shell.Interop.DEBUG_LAUNCH_OPERATION;
using IVsDebugger2 = Microsoft.VisualStudio.Shell.Interop.IVsDebugger2;
using IVsUIShell = Microsoft.VisualStudio.Shell.Interop.IVsUIShell;
using StringComparison = System.StringComparison;
using SVsShellDebugger = Microsoft.VisualStudio.Shell.Interop.SVsShellDebugger;
using SVsUIShell = Microsoft.VisualStudio.Shell.Interop.SVsUIShell;

namespace JellequinVs.Debug
{
    static class DebugLauncher
    {
        internal static int QueryDebugLaunch(uint flags, out int fCanLaunch)
        {
            fCanLaunch = 1;
            return VSConstants.S_OK;
        }

        internal static int DebugLaunch(uint grfLaunch, JellequinProjectNode projectManager)
        {
            string GetBuildPropertyValue(string name)
                => projectManager.BuildProject.Properties.FirstOrDefault(x => string.Equals(x.Name, name, StringComparison.Ordinal))?.EvaluatedValue
                   ?? projectManager.BuildProject.Items.FirstOrDefault(x => string.Equals(x.ItemType, name, StringComparison.Ordinal))?.EvaluatedInclude;

            //Computer\HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\dotnet\Setup\InstalledVersions\x64\sharedfx\Microsoft.NETCore.App
            //"ComSpec" = "C:\\Windows\\system32\\cmd.exe"
            //"Path" = "C:\\Windows\\system32;C:\\Windows;C:\\Windows\\System32\\Wbem;C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\;C:\\Program Files\\dotnet\\;C:\\Users\\Ja\\AppData\\Local\\Microsoft\\WindowsApps;"

            DebugTargetInfo info = new DebugTargetInfo
            {
                CurrentDirectory = GetBuildPropertyValue("IntermediateOutputPath") ?? projectManager.ProjectFolder,
                DebugEngines = new[] { VSConstants.DebugEnginesGuids.ManagedOnly_guid },
                LaunchFlags = __VSDBGLAUNCHFLAGS.DBGLAUNCH_DetachOnStop | __VSDBGLAUNCHFLAGS.DBGLAUNCH_StopDebuggingOnEnd,
                LaunchOperation = DEBUG_LAUNCH_OPERATION.DLO_CreateProcess,
                Executable = GetBuildPropertyValue("ComSpec"),
                //Arguments = $@"/C ""C:\Program Files\dotnet\dotnet.exe"" exec ""{GetBuildPropertyValue("IntermediateAssembly")}"""
                Arguments = $@"/C dotnet exec ""{GetBuildPropertyValue("IntermediateAssembly")}"""
            };

            /*DebugTargetInfo info = new DebugTargetInfo
            {
                CurrentDirectory = GetBuildPropertyValue("IntermediateOutputPath") ?? this.ProjectManager.ProjectFolder,
                DebugEngines = new[] { VSConstants.DebugEnginesGuids.ManagedOnly_guid },
                LaunchFlags = __VSDBGLAUNCHFLAGS.DBGLAUNCH_DetachOnStop | __VSDBGLAUNCHFLAGS.DBGLAUNCH_StopDebuggingOnEnd,
                LaunchOperation = DEBUG_LAUNCH_OPERATION.DLO_CreateProcess,
                Executable = @"C:\Program Files\dotnet\dotnet.exe",
                Arguments = "exec "+GetBuildPropertyValue("IntermediateAssembly")
            };*/

            var debugger = (IVsDebugger2)Microsoft.VisualStudio.Shell.Package.GetGlobalService(typeof(SVsShellDebugger));
            int result = debugger.LaunchDebugTargets(info);

            if (result != VSConstants.S_OK)
            {
                IVsUIShell uishell = (IVsUIShell)Microsoft.VisualStudio.Shell.Package.GetGlobalService(typeof(SVsUIShell));
                string message = GetErrorInfo(uishell);
            }
            return result;
        }

        static string GetErrorInfo(IVsUIShell shell)
        {
            ErrorHandler.ThrowOnFailure(shell.GetErrorInfo(out string message));
            return message;
        }
    }
}
