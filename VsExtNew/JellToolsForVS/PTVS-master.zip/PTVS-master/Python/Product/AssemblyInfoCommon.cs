// <copyright>
// Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>

using System.Reflection;

// The following assembly information is common to all Python Tools for Visual
// Studio assemblies.
// If you get compiler errors CS0579, "Duplicate '<attributename>' attribute", check your 
// Properties\AssemblyInfo.cs file and remove any lines duplicating the ones below.
// (See also AssemblyVersion.cs in this same directory.)
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("Python support for Microsoft® Visual Studio®")]
[assembly: AssemblyCopyright("© Microsoft Corporation")]
