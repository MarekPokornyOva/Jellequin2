For building and running through VS (in the Experimental hive), copy these file to:

 %ProgramFiles(x86)%\MSBuild\Microsoft\Visual Studio\v1x.0\Python Tools

As part of the build process, the actual targets files will be copied to the output directory. These files will load
the copies in:

 %LocalAppData%\Microsoft\VisualStudio\1x.0\Extensions\Microsoft Corporation\Python\3.0
