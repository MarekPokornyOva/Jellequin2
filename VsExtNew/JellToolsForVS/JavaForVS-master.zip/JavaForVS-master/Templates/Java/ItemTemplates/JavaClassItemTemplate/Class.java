package $rootnamespace$;

class $safeitemrootname$ {
}
