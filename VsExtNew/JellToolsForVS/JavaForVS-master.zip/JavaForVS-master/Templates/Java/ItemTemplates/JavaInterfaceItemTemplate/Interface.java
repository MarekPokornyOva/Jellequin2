package $rootnamespace$;

interface $safeitemrootname$ {
}
