﻿namespace Tvl.Java.DebugHost
{
    public enum JvmEventMode
    {
        Disable = 0,
        Enable = 1,
    }
}
