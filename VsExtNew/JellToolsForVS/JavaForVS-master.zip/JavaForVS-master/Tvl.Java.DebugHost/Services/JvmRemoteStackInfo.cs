﻿namespace Tvl.Java.DebugHost.Services
{
    public struct JvmRemoteStackInfo
    {
    }
}
