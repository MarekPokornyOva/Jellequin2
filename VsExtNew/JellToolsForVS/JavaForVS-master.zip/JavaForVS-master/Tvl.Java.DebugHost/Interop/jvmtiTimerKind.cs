﻿namespace Tvl.Java.DebugHost.Interop
{
    public enum jvmtiTimerKind
    {
        UserCpu = 30,
        TotalCpu = 31,
        Elapsed = 32,
    }
}
