﻿namespace Tvl.Java.DebugHost.Interop
{
    public enum jniVersion
    {
        Version1_1 = 0x00010001,
        Version1_2 = 0x00010002,
        Version1_4 = 0x00010004,
        Version1_6 = 0x00010006,
    }
}
