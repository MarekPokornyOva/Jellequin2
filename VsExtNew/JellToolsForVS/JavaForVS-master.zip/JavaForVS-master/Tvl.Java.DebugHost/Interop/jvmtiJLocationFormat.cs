﻿namespace Tvl.Java.DebugHost.Interop
{
    public enum jvmtiJLocationFormat
    {
        JvmBci = 1,
        MachinePC = 2,
        Other = 0
    }
}
