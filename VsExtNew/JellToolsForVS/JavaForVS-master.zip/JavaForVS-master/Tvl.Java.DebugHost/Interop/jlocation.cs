﻿namespace Tvl.Java.DebugHost.Interop
{
    public struct jlocation
    {
        public long Value;

        public jlocation(long value)
        {
            Value = value;
        }
    }
}
