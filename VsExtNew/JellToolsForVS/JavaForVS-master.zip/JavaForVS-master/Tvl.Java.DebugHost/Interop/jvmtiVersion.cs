﻿namespace Tvl.Java.DebugHost.Interop
{
    public enum jvmtiVersion
    {
        Version1 = 0x30010000,
        Version1_0 = 0x30010000,
        Version1_1 = 0x30010100,
        Version1_2 = 0x30010200,
    }
}
