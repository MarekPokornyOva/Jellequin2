﻿namespace Tvl.Java.DebugHost.Interop
{
    internal enum jobjectRefType
    {
        Invalid = 0,
        Local = 1,
        Global = 2,
        WeakGlobal = 3
    }
}
