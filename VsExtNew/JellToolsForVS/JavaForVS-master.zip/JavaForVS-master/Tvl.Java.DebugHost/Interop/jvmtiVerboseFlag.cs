﻿namespace Tvl.Java.DebugHost.Interop
{
    internal enum jvmtiVerboseFlag
    {
        Other = 0,
        GC = 1,
        Class = 2,
        Jni = 4
    }
}
