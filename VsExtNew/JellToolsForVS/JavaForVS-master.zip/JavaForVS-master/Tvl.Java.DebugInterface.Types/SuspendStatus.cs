﻿namespace Tvl.Java.DebugInterface.Types
{
    public enum SuspendStatus
    {
        None = 0,
        Suspended = 1,
    }
}
