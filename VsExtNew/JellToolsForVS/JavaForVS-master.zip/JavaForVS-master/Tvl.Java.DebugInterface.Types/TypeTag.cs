﻿namespace Tvl.Java.DebugInterface.Types
{
    public enum TypeTag
    {
        Invalid = 0,
        Class = 1,
        Interface = 2,
        Array = 3,
    }
}
