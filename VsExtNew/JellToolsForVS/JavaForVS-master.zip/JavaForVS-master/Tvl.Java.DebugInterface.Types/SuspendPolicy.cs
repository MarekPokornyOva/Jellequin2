﻿namespace Tvl.Java.DebugInterface.Types
{
    public enum SuspendPolicy
    {
        None = 0,
        EventThread = 1,
        All = 2,
    }
}
