# Java Language Support for Visual Studio

[![Join the chat at https://gitter.im/tunnelvisionlabs/JavaForVS](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/tunnelvisionlabs/JavaForVS?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

This repository contains the Java-related features originally developed in [tunnelvisionlabs/LangSvcV2][1]. It is the
home for ongoing development on the [Java Language Support][2] extension for Visual Studio.

[1]: https://github.com/tunnelvisionlabs/LangSvcV2
[2]: https://visualstudiogallery.msdn.microsoft.com/bc561769-36ff-4a40-9504-e266e8706f93
