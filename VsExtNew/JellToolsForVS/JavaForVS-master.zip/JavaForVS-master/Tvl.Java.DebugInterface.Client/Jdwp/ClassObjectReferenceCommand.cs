﻿namespace Tvl.Java.DebugInterface.Client.Jdwp
{
    public enum ClassObjectReferenceCommand : byte
    {
        Invalid = 0,
        ReflectedType = 1,
    }
}
