﻿namespace Tvl.Java.DebugInterface.Client.Jdwp
{
    public enum StringReferenceCommand : byte
    {
        Invalid = 0,
        Value = 1,
    }
}
