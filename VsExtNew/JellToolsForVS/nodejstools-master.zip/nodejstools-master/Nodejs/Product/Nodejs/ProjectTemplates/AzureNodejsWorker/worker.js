/*
 * Worker roles run asynchronous, long-running, or perpetual 
 * tasks independent of user interaction or input. 
 */
'use strict';

while (true) {

}
