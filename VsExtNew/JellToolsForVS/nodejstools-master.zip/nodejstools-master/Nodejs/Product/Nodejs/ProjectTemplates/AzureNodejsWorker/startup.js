/** Placeholder for role startup **/
'use strict';
