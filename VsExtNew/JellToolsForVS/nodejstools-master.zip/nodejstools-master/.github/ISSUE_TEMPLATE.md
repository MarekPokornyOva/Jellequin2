<!--- To report a bug, please fill out the fields below. Feel free to add additional information too.
        For feature requests or questions, you can clear this text.  -->

##### Expected Behavior 

##### Actual Behavior 

<!---(from Help -> About Microsoft Visual Studio)-->
- NTVS Version:
- Visual Studio Version: 
- Node.js Version: 

##### Steps to Reproduce
1. 
2. 
